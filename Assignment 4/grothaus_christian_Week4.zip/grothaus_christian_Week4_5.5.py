alphabet = 'abcdefghijklmnopqrstuvwxyz'
print(alphabet[0:len(alphabet)//2])
print(alphabet[:len(alphabet)//2])
print(alphabet[len(alphabet)//2:26])
print(alphabet[len(alphabet)//2:])
print(alphabet[::2])
print(alphabet[::-3])