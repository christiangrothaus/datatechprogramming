from math import prod

def product(*args):
  print(prod(args))

product(1,2,3,4,5,6,7,8,9,10)
product(0)
product(89,28)
product(123,72,-2)
product(3.14,2.18)
product(-1,2)